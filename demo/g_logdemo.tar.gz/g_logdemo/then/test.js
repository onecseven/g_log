const {log} = require('g_log')

log('hey guys how are you','this is just to show', 'paragraphs')
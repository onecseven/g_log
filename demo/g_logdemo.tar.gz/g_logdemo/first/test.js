const {log} = require('g_log')

log([12,3,4,6,7,3,4], {"hi": "guys"})
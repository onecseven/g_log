const {log} = require('g_log')

log('!!!!!!!!!!!!!!!!!!!!!!!1')
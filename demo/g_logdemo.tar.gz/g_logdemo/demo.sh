node ./node_modules/g_log/watch.js &

while true
do
  node --no-warnings ./first/test.js
  sleep 1  
  node --no-warnings ./get/test.js
  sleep 1
  node --no-warnings ./monies/test.js
  sleep 1
  node --no-warnings ./then/test.js
  sleep 1
  node --no-warnings ./youget/test.js
  sleep 1
  node --no-warnings ./honies/test.js
  sleep 2
done
